package com.ycs.smartcanteen.ui

class Bean {
    data class DishItem(var name:String,var type:String,var src:Int)
}